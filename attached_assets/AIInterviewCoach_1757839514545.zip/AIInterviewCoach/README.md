# AI-Powered Excel Mock Interviewer

An intelligent web application that conducts comprehensive Excel skills assessments using Google Gemini AI with voice capabilities.

## 🚀 Features

### Core Functionality
- **AI-Powered Interviews**: Uses Google Gemini AI for intelligent question generation and response evaluation
- **Voice Integration**: Speech-to-text input and text-to-speech output for natural conversation
- **Structured Interview Flow**: Professional interviewer experience with introduction, assessment, and conclusion
- **Real-time Evaluation**: Instant feedback and scoring of candidate responses
- **Comprehensive Reporting**: Detailed performance analysis with strengths, improvements, and recommendations

### Technical Capabilities
- **Multi-turn Conversations**: Contextual follow-up questions based on candidate responses
- **Interview State Management**: Persistent session tracking and progress monitoring
- **Adaptive Questioning**: Questions tailored to candidate experience level and performance
- **Performance Analytics**: Score tracking, category analysis, and trend identification
- **Export Functionality**: Download reports in JSON and text formats

## 🛠️ Technology Stack

- **Frontend**: Streamlit web framework
- **AI Engine**: Google Gemini AI (gemini-2.5-flash/pro models)
- **Speech Services**: Google Cloud Speech-to-Text and Text-to-Speech APIs
- **Audio Processing**: Custom audio utilities for voice interaction
- **Data Models**: Pydantic-based structured data management
- **Deployment**: Replit hosting with public URL access

## 🏗️ Architecture

