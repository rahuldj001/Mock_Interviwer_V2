# Overview

AI-Powered Excel Mock Interviewer is an intelligent web application that conducts comprehensive Excel skills assessments using Google Gemini AI with voice capabilities. The system provides structured interview flows with real-time AI evaluation, voice integration for natural conversation, and detailed performance reporting. It's designed to simulate professional Excel technical interviews with adaptive questioning based on candidate experience and performance.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: Streamlit web application with component-based architecture
- **UI Components**: Custom audio recording interfaces, real-time chat displays, and report generation views
- **State Management**: Session-based state persistence using Streamlit's session state for interview progress tracking
- **Audio Integration**: WebRTC streaming for real-time audio capture with fallback mechanisms

## Backend Architecture
- **Service Layer**: Modular service architecture with separate concerns for AI, speech, and interview management
- **AI Integration**: Google Gemini AI service for question generation, response evaluation, and conversational flow
- **Speech Processing**: Google Cloud Speech-to-Text and Text-to-Speech APIs for voice interaction
- **Interview Logic**: Centralized interview manager handling question progression, evaluation, and reporting

## Data Models
- **Structured Data**: Pydantic-based models for type safety and validation
- **Interview State**: Comprehensive session tracking with candidate information, responses, and evaluations
- **Question Management**: Categorized question bank with difficulty levels and follow-up capabilities
- **Evaluation System**: Multi-dimensional scoring with technical accuracy, knowledge depth, and improvement recommendations

## Audio Processing
- **Real-time Capture**: WebRTC-based audio streaming with browser compatibility checks
- **Format Support**: Multi-format audio handling (WAV, MP3, OGG, WebM) with validation
- **Audio Utilities**: Custom processing for format conversion, validation, and base64 encoding

## Interview Flow Management
- **Adaptive Questioning**: AI-driven question selection based on candidate experience and performance
- **Context Awareness**: Multi-turn conversation handling with follow-up question generation
- **Progress Tracking**: Real-time interview state management with completion detection
- **Report Generation**: Comprehensive performance analysis with exportable formats

# External Dependencies

## AI Services
- **Google Gemini AI**: Primary AI engine using gemini-2.5-flash/pro models for question generation and evaluation
- **API Integration**: RESTful API communication with structured JSON responses

## Speech Services
- **Google Cloud Speech-to-Text**: Audio transcription with multiple language support
- **Google Cloud Text-to-Speech**: Voice synthesis with configurable voice parameters
- **Audio Processing**: Real-time speech recognition and synthesis capabilities

## Web Technologies
- **Streamlit**: Core web framework for rapid application development
- **Streamlit WebRTC**: Real-time communication for audio streaming (optional dependency)
- **Browser APIs**: WebRTC integration for direct audio capture

## Development Tools
- **Python Ecosystem**: Core application runtime with modern Python features
- **JSON Processing**: Structured data exchange with AI services
- **Base64 Encoding**: Audio data transmission and storage
- **Logging**: Application monitoring and error tracking

## Deployment Platform
- **Replit Hosting**: Cloud-based deployment with public URL access
- **Environment Variables**: Secure API key management for external services